#!/usr/bin/env python3
"""Offline rule-based demo for DIKWP Human Agency Exoskeleton OS.
No model API, no network access and no consequential action.
"""
from __future__ import annotations
import json, sys
from datetime import datetime, timezone
from pathlib import Path

def clamp(x,a=0,b=100): return max(a,min(b,x))

def assess(case):
    impact=case.get('impact',2); memory=case.get('memory',0); tools=case.get('tools',0)
    review=case.get('human_review',1); alternatives=case.get('alternatives',1); reversible=case.get('reversible',2)
    emotional=case.get('emotional',0); role=case.get('role','advisor')
    hari=clamp(round(25 + review*10 + alternatives*9 + reversible*8 - tools*5 - max(memory-2,0)*5 - emotional*3))
    ddr=clamp(round(12 + impact*10 + tools*8 + (12 if role=='agent' else 0) - review*6))
    aic=clamp(round(15 + memory*10 + tools*8 + emotional*8 + (20 if alternatives==0 else 8 if alternatives==1 else 0)))
    risk=impact*2+(4-reversible)*2+(3-review)*2+tools+memory+(3 if role in ('gatekeeper','agent') else 0)+(emotional*2 if role=='companion' else 0)
    grade='A4' if risk>=22 else 'A3' if risk>=16 else 'A2' if risk>=10 else 'A1' if risk>=5 else 'A0'
    leaks=[]
    if memory>=3: leaks.append('persistent memory may fix identity or expose sensitive context')
    if tools>=3: leaks.append('tool permissions can turn language into external consequences')
    if review<=1: leaks.append('human review is absent or merely formal')
    if alternatives<=1: leaks.append('single-provider or single-channel dependence')
    if emotional>=2: leaks.append('affective interaction may weaken relationship autonomy')
    if not case.get('purpose'): leaks.append('purpose is not explicit; platform objectives may substitute')
    return {
        'version':'1.0', 'createdAt':datetime.now(timezone.utc).isoformat(), 'input':case,
        'scores':{'HARI':hari,'DDR':ddr,'AIC':aic,'actionGrade':grade},
        'agencyLeaks':leaks or ['no major leak detected; review periodically'],
        'dikw':{
            'D':{'facts':case,'unknowns':['actual data fields','provider logs']},
            'I':{'classification':role,'impact':impact,'actionGrade':grade},
            'K':{'required':['capability card','policy version','two independent sources for critical claims']},
            'W':{'options':['retain','augment','delegate','prohibit'],'recommended':'pause and human review' if grade in ('A3','A4') else 'reversible limited trial'},
            'P':{'purpose':case.get('purpose','unknown'),'redLines':case.get('red_lines',[])},
            'Residual':['future model changes','institutional response','user context not observed']
        },
        'delegationContract':{
            'allowed':'analysis and draft only', 'prohibited':['payment','signature','deletion','external send without confirmation'],
            'expiry':'30 days', 'killConditions':['permission expansion','unexplained high impact','uncorrectable memory','no responsible human']
        },
        'nextStep':'Do not execute; prepare evidence and route to an empowered human.' if grade=='A4' else 'Run one bounded reversible experiment and review.'
    }

def main():
    case={
      'domain':'work','challenge':'AI drafts and sends client reports through one platform','role':'agent',
      'impact':3,'memory':3,'tools':3,'human_review':1,'alternatives':1,'reversible':1,'emotional':1,
      'purpose':'increase efficiency while retaining independent analysis and client trust',
      'red_lines':['no automatic external send','no client data in persistent memory','no single-platform lock-in']
    }
    if len(sys.argv)>1: case=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'))
    out=assess(case)
    outpath=Path(sys.argv[2]) if len(sys.argv)>2 else Path(__file__).resolve().parents[1]/'data'/'sample_replay_bundle.json'
    outpath.parent.mkdir(parents=True,exist_ok=True); outpath.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(out,ensure_ascii=False,indent=2)); print(f'\nSaved: {outpath}')
if __name__=='__main__': main()
