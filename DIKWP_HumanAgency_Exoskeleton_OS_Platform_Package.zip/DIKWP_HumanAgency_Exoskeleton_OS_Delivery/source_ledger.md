# Source Ledger

Official and public sources used as normative or contextual references:

## S1 — International Labour Organization
- **Title:** Generative AI and Jobs: A Refined Global Index of Occupational Exposure (2025)
- **URL:** https://www.ilo.org/publications/generative-ai-and-jobs-refined-global-index-occupational-exposure
- **Use:** One in four workers are in occupations with some exposure; the largest likely effect is transformation of work rather than simple elimination.

## S2 — NIST
- **Title:** AI Risk Management Framework 1.0 and AI RMF Playbook
- **URL:** https://www.nist.gov/itl/ai-risk-management-framework
- **Use:** Govern, Map, Measure and Manage; explicit roles, oversight and documentation.

## S3 — NIST
- **Title:** Artificial Intelligence Risk Management Framework: Generative Artificial Intelligence Profile (NIST AI 600-1)
- **URL:** https://www.nist.gov/publications/artificial-intelligence-risk-management-framework-generative-artificial-intelligence
- **Use:** Generative AI may require additional human review, tracking, documentation and management oversight.

## S4 — UNESCO
- **Title:** Recommendation on the Ethics of Artificial Intelligence
- **URL:** https://www.unesco.org/en/artificial-intelligence/recommendation-ethics
- **Use:** Human-rights-centred principles including proportionality, safety, privacy, transparency, accountability and human oversight.

## S5 — OECD
- **Title:** OECD AI Principles
- **URL:** https://www.oecd.org/en/topics/ai-principles.html
- **Use:** Innovative and trustworthy AI that respects human rights, democratic values, transparency and accountability.

## S6 — European Union
- **Title:** Regulation (EU) 2024/1689, Article 86
- **URL:** https://eur-lex.europa.eu/eli/reg/2024/1689/oj/eng
- **Use:** A right to an explanation for certain individual decisions based on high-risk AI outputs.

## S7 — W3C
- **Title:** Verifiable Credentials Data Model v2.0
- **URL:** https://www.w3.org/TR/vc-data-model-2.0/
- **Use:** User-held, machine-verifiable, privacy-aware digital credentials and selective disclosure.

## S8 — Yucong Duan
- **Title:** GitHub open-source profile and DIKWP prototypes
- **URL:** https://github.com/YucongDuan
- **Use:** Open-source work around DIKWP, evidence ledgers, semantic routing, agent coordination and artificial consciousness.

## S9 — Yucong Duan
- **Title:** ResearchGate profile and DIKWP / semantic mathematics materials
- **URL:** https://www.researchgate.net/profile/Yucong-Duan
- **Use:** Public research materials on DIKWP, semantic mathematics, white-box evaluation and artificial consciousness.

## Interpretation boundary
DIKWP and artificial-consciousness materials are used as theory and engineering inspiration. Claims are not treated as established simply because they appear in a technical report, repository or public profile. The platform deliberately makes subjective-machine-experience questions non-blocking and governs observable permissions, evidence, consequences and accountable human roles.