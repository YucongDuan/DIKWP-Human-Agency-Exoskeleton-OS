# Three-Path Future Portfolio

## Path A — Deepen
- Hypothesis:
- Human advantage:
- Reversible experiment:
- Evidence:
- Trigger / kill condition:

## Path B — Adjacent
- Hypothesis:
- Transferable skills:
- Reversible experiment:
- Evidence:
- Trigger / kill condition:

## Path C — Create
- New need / audience:
- Minimum service or product:
- Reversible experiment:
- Evidence:
- Trigger / kill condition:
