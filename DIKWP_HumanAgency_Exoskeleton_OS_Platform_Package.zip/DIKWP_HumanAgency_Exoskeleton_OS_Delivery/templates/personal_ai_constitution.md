# Personal AI Constitution

## Purpose
- My primary purpose:
- Beneficiaries:
- What I refuse to optimise away:

## Memory
- Allowed memory:
- Retention:
- Correction / deletion / export:

## Tools and Actions
- Read-only:
- Reversible actions:
- Actions requiring a second human:
- Prohibited actions:

## Relationships
- AI must not request exclusivity, secrecy or loyalty.
- Commercial goals must be disclosed.
- Human support network:

## Rights and Exit
- Explanation channel:
- Human review channel:
- Export format:
- Kill conditions:
- Next review date:
