Subject: Request for explanation, data correction and meaningful human review

Please explain the role of any AI or automated system in this decision; the principal data and sources used; the main factors, classifications or thresholds that materially influenced the outcome; the policy or rule applied; the level and substance of human review; known limitations or uncertainty; and the procedures to correct data, provide context, obtain human review, appeal the decision and seek an effective remedy.

I also request a copy of the data about me that was materially used and the deadline for any challenge.
