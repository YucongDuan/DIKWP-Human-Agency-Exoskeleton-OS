# AI Relationship Boundary Protocol
- The system must identify itself as non-human.
- It must disclose persistent memory and commercial goals.
- It must not request exclusivity, secrecy, obedience or financial loyalty.
- It must support easy exit and deletion.
- It must encourage appropriate human support when dependence, crisis or high-impact decisions arise.
- Red-line phrases / behaviours:
- Trusted human contacts:
- Kill conditions:
