# 30-Day Human Agency Sprint
- Days 1–3: map 10 AI exposures.
- Days 4–7: write Personal AI Constitution and memory contracts.
- Days 8–12: run two no-AI baselines.
- Days 13–18: create Deepen / Adjacent / Create paths.
- Days 19–23: prepare explanation and appeal templates.
- Days 24–27: activate three human support nodes.
- Days 28–30: run one reversible experiment and review.
